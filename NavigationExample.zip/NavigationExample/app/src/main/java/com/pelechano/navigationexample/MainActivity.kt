package com.pelechano.navigationexample

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.pelechano.navigationexample.navigation.NavigationWrapper
import com.pelechano.navigationexample.ui.theme.NavigationExampleTheme

/*
https://developer.android.com/develop/ui/compose/navigation
Afegir Dependència en el app module Graddle

plugins {
    id("org.jetbrains.kotlin.plugin.serialization") version libs.versions.kotlin.get()
}

dependencies {
    implementation("androidx.navigation:navigation-compose:2.9.5")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.3")
}
*/

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NavigationExampleTheme {
                NavigationWrapper()
            }
        }
    }
}
