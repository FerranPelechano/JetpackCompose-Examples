package com.pelechano.navigationexample.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.pelechano.navigationexample.screens.DetailScreen
import com.pelechano.navigationexample.screens.HomeScreen
import com.pelechano.navigationexample.screens.SplashScreen

@Composable
fun NavigationWrapper(){

    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = Splash) {

        //Pantalla Splash inicial que permetrà navegar a Home
        composable<Splash> {
            SplashScreen { navController.navigate(Home) }
        }
        //Pantalla Home que deixarà afegir un valor i navegarà a Detail
        composable<Home> {
            HomeScreen {name -> navController.navigate(Detail(name=name)) }
        }
        //Pantalla Detail que mostrarà el valor afegit a Home i permetrà tornar a Home netejant pila
        composable<Detail>{backStackEntry ->
            val detail:Detail=backStackEntry.toRoute<Detail>()
            DetailScreen(detail.name) { navController.navigate(Home){
                    popUpTo<Home>{inclusive = true}
                }
            }
        }

    }
}