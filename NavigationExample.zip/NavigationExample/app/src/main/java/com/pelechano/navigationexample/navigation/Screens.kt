package com.pelechano.navigationexample.navigation

import kotlinx.serialization.Serializable

@Serializable
object Splash

@Serializable
object Home

@Serializable
//Si vaig a passar valors ha de ser un data class en compte d'un object
data class Detail (val name:String)
