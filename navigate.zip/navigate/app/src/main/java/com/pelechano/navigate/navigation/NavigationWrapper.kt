package com.pelechano.navigate.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.pelechano.navigate.R
import com.pelechano.navigate.screens.DetailsScreen
import com.pelechano.navigate.screens.ListScreen
import com.pelechano.navigate.screens.SplashScreen
import kotlinx.coroutines.delay

@Composable
fun NavigationWrapper() {

    val navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = "splash_screen"
    ) {
        composable("splash_screen") {backStackEntry->
            SplashScreen()
            LaunchedEffect(backStackEntry ) {
                delay(3000)
                navController.popBackStack()
                navController.navigate("list_screen")
            }
        }
        composable("list_screen") {
            ListScreen { name ->
                navController.navigate("detail_screen/$name")
            }
        }
        composable(
            "detail_screen/{name}",
            arguments = listOf(
                navArgument("name") {type = NavType.StringType}
            )
        ) {backStackEntry ->

            val name = backStackEntry.arguments?.getString("name") ?: stringResource(R.string.details_default)

            DetailsScreen(name){navController.navigateUp()}
        }


    }
}