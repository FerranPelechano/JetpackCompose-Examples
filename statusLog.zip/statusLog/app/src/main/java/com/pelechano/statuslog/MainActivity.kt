package com.pelechano.statuslog

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.pelechano.statuslog.ui.theme.StatusLogTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(getString(R.string.tag), getString(R.string.message_onCreate))
        enableEdgeToEdge()
        setContent {
            StatusLogTheme {
                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding(),
                ) {
                    Greeting(name = "Android", modifier = Modifier)
                }
            }
        }
    }
    override fun onStart() {
        super.onStart()
        Log.d(getString(R.string.tag), getString(R.string.message_onStart))
    }
    override fun onResume() {
        super.onResume()
        Log.d(getString(R.string.tag), getString(R.string.message_onResume))
    }

    override fun onRestart() {
        super.onRestart()
        Log.d(getString(R.string.tag), getString(R.string.message_onRestart))
    }

    override fun onPause() {
        super.onPause()
        Log.d(getString(R.string.tag), getString(R.string.message_onPause))
    }

    override fun onStop() {
        super.onStop()
        Log.d(getString(R.string.tag), getString(R.string.message_onStop))
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(getString(R.string.tag), getString(R.string.message_onDestroy))
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = Modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    StatusLogTheme {
        Greeting("Android")
    }
}