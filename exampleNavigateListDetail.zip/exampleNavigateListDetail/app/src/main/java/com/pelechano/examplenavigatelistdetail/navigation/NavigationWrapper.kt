package com.pelechano.examplenavigatelistdetail.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.pelechano.examplenavigatelistdetail.screens.DetailsScreen
import com.pelechano.examplenavigatelistdetail.screens.ListScreen
import com.pelechano.examplenavigatelistdetail.screens.SplashScreen
import kotlinx.coroutines.delay

@Composable
fun NavigationWrapper() {
    val navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = "splash_screen"
    ) {
        composable("splash_screen") { backStackEntry ->
            SplashScreen()
            LaunchedEffect(backStackEntry) {
                delay(3000)
                navController.popBackStack()
                navController.navigate("list_screen")
            }
        }
        composable("list_screen") {
            ListScreen { id ->
                navController.navigate("detail_screen/$id")
            }
        }

        composable(
            route = "detail_screen/{id}",
            arguments = listOf(
                navArgument("id"){type=NavType.IntType}
            )
        ) {
                backStackEntry ->
            val id = backStackEntry.arguments?.getInt("id") ?: 1
            DetailsScreen(id){navController.navigateUp()}
        }

    }
}
