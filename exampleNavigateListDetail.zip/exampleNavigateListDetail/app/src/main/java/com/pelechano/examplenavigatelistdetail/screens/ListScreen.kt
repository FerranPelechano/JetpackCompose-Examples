package com.pelechano.examplenavigatelistdetail.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.pelechano.examplenavigatelistdetail.R
import com.pelechano.examplenavigatelistdetail.data.itemList
import com.pelechano.examplenavigatelistdetail.ui.theme.ExampleNavigateListDetailTheme

@Composable
fun ListScreen (
    onClick: (Int) -> Unit = {}
) {

        Surface(
            color = MaterialTheme.colorScheme.background,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {

        LazyColumn (
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.padding(16.dp)
        ){
            items(itemList) { item ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    modifier = Modifier
                        .fillMaxWidth()
                ) {
                    Image(
                        painterResource(item.image),
                        stringResource(item.name)
                    )
                    Text(
                        stringResource(item.name),
                        Modifier
                            .padding(16.dp),
                    )
                    Button(
                        onClick = { onClick(item.id) }) {
                        Text("${stringResource(R.string.list_button1)} ${item.id}")
                    }
                }
                HorizontalDivider()
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun ListScreenPreview() {
    ExampleNavigateListDetailTheme {
        ListScreen {}
    }
}
