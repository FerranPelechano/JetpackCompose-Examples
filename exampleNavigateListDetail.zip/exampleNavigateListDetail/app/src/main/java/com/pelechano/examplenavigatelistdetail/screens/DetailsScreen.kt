package com.pelechano.examplenavigatelistdetail.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Button
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.pelechano.examplenavigatelistdetail.R
import com.pelechano.examplenavigatelistdetail.data.itemList
import com.pelechano.examplenavigatelistdetail.ui.theme.ExampleNavigateListDetailTheme

@Composable
fun DetailsScreen (
    id : Int,
    onClick : () -> Unit
) {
    val item = itemList.find { it.id == id }

    if (item == null) {return}

    Surface(
        modifier = Modifier
            .fillMaxSize()
    ) {
        Column(
            verticalArrangement = Arrangement.SpaceEvenly,
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
        ){

            Image(
                painterResource(item.image),
                stringResource(item.name),
                modifier = Modifier
                    .fillMaxWidth(),
                contentScale = ContentScale.Crop
            )
            Spacer(modifier = Modifier.height(16.dp))

            Text(stringResource(item.name))
            Spacer(modifier = Modifier.height(16.dp))
            Text(id.toString())
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = {onClick()}){
                Text(stringResource(R.string.details_button))
            }
        }

    }
}

@Preview(showBackground = true)
@Composable
fun DetailsScreenPreview(){
    ExampleNavigateListDetailTheme {
        DetailsScreen(1) {}
    }
}