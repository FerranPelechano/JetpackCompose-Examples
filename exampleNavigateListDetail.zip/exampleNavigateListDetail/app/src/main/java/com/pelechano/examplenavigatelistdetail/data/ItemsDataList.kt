package com.pelechano.examplenavigatelistdetail.data

import com.pelechano.examplenavigatelistdetail.R
import com.pelechano.examplenavigatelistdetail.model.Items

val itemList = listOf<Items> (
    Items(1, R.string.item1, R.drawable.item1),
    Items(2, R.string.item2, R.drawable.item2),
    Items(3, R.string.item3, R.drawable.item3),
    Items(4, R.string.item4, R.drawable.item4),
    Items(5, R.string.item5, R.drawable.item5),
    Items(6, R.string.item6, R.drawable.item6),
    Items(7, R.string.item7, R.drawable.item7),
    Items(8, R.string.item8, R.drawable.item8),
    Items(9, R.string.item9, R.drawable.item9),
    Items(10, R.string.item10, R.drawable.item10),
    Items(11, R.string.item11, R.drawable.item1),
    Items(12, R.string.item12, R.drawable.item2),
    Items(13, R.string.item13, R.drawable.item3),
    Items(14, R.string.item14, R.drawable.item4),
    Items(15, R.string.item15, R.drawable.item5),
    Items(16, R.string.item16, R.drawable.item6),
    Items(17, R.string.item17, R.drawable.item7),
    Items(18, R.string.item18, R.drawable.item8),
    Items(19, R.string.item19, R.drawable.item9),
    Items(20, R.string.item20, R.drawable.item10),
    Items(21, R.string.item21, R.drawable.item1),
    Items(22, R.string.item22, R.drawable.item2),
    Items(23, R.string.item23, R.drawable.item3),
    Items(24, R.string.item24, R.drawable.item4),
    Items(25, R.string.item25, R.drawable.item5),
    Items(26, R.string.item26, R.drawable.item6),
    Items(27, R.string.item27, R.drawable.item7),
    Items(28, R.string.item28, R.drawable.item8),
    Items(29, R.string.item29, R.drawable.item9),
    Items(30, R.string.item30, R.drawable.item10),
)
