package com.pelechano.galeriaremota.data

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET

data class Photo(
    val name: String,
    val url: String
)
fun getImageUrl(photo: Photo): String {
    val id = photo.url.trimEnd('/').split("/").last()
    return "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/$id.png"
}
data class RetrofitResponse(
    val results: List<Photo>
)

interface ApiService {
    @GET("pokemon?limit=50")
    suspend fun getPhotos(): RetrofitResponse
}

object RetrofitInstance {
    private const val BASE_URL = "https://pokeapi.co/api/v2/"

    val api: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}

