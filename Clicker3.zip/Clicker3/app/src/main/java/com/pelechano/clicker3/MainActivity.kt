package com.pelechano.clicker3

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.pelechano.clicker3.ui.theme.Clicker3Theme
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.lang.Integer.toString

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Clicker3Theme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Screen(
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")
val SIZE1 = intPreferencesKey("size1")
val SIZE2 = intPreferencesKey("size2")
val SIZE3 = intPreferencesKey("size3")


@Composable
fun Screen(modifier: Modifier = Modifier) {
    val context= LocalContext.current
    val coroutineScope= rememberCoroutineScope ()

    var size1:Int by rememberSaveable {mutableStateOf(20)}
    var size2:Int by rememberSaveable {mutableStateOf(20)}
    var size3:Int by rememberSaveable {mutableStateOf(20)}

    var isLoadingInitialValues by remember { mutableStateOf(true) }
    LaunchedEffect(key1 = Unit) {
        isLoadingInitialValues = true

        // Llegeix size1
        val savedValueFlowSize1 = context.dataStore.data
            .map { preferences -> preferences[SIZE1] ?: 20 }
            .firstOrNull()
        if (savedValueFlowSize1 != null) {
            size1 = savedValueFlowSize1
        }

        // Llegeix size2
        val savedValueFlowSize2 = context.dataStore.data
            .map { preferences -> preferences[SIZE2] ?: 20 }
            .firstOrNull()
        if (savedValueFlowSize2 != null) {
            size2 = savedValueFlowSize2
        }

        // Llegeix size3
        val savedValueFlowSize3 = context.dataStore.data
            .map { preferences -> preferences[SIZE3] ?: 20 }
            .firstOrNull()
        if (savedValueFlowSize3 != null) {
            size3 = savedValueFlowSize3
        }

        isLoadingInitialValues = false
    }
    if (isLoadingInitialValues) {
        Text(stringResource(R.string.loading))
    } else {
        Column(
            modifier = Modifier.fillMaxHeight(),
            verticalArrangement = Arrangement.SpaceEvenly,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Clicker 3",
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(
                    painterResource(R.drawable.outline_arrow_upward_alt_24),
                    contentDescription = "",
                    modifier=Modifier.size(
                        height = size1.dp,
                        width = size1.dp
                    )
                )
                Spacer(Modifier.width(8.dp))
                Image(
                    painterResource(R.drawable.outline_arrow_upward_alt_24),
                    contentDescription = "",
                    modifier=Modifier.size(
                        height = size2.dp,
                        width = size2.dp
                    )
                )
                Spacer(Modifier.width(8.dp))
                Image(
                    painterResource(R.drawable.outline_arrow_upward_alt_24),
                    contentDescription = "",
                    modifier=Modifier.size(
                        height = size3.dp,
                        width = size3.dp
                    )
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(toString(size1))
                Spacer(Modifier.width(8.dp))
                Text(toString(size2))
                Spacer(Modifier.width(8.dp))
                Text(toString(size3))
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(onClick = {
                    size1+=5
                    coroutineScope.launch {context.dataStore.edit { settings -> settings[SIZE1] = size1}
                    }

                }) {
                    Text(stringResource(R.string.button1))
                }
                Spacer(Modifier.width(8.dp))
                Button(onClick = {
                    size2+=5
                    coroutineScope.launch {
                        context.dataStore.edit { settings -> settings[SIZE2] = size2 }
                    }
                }) {
                    Text(stringResource(R.string.button2))
                }
                Spacer(Modifier.width(8.dp))
                Button(onClick = {
                    size3+=5
                    coroutineScope.launch {
                        context.dataStore.edit { settings -> settings[SIZE3] = size3 }
                    }
                }) {
                    Text(stringResource(R.string.button3))
                }
            }
        }
    }

}

@Preview(showBackground = true)
@Composable
fun ScreenPreview() {
    Clicker3Theme {
        Screen()
    }
}