package com.pelechano.todokmp.quiz

import androidx.compose.runtime.mutableStateOf



class QuizEngine {

    private val _totalQuestions = 5
    private val selectedQuestions =
        QuizRepository.questions.shuffled().take(_totalQuestions)

    private var _index = mutableStateOf(0)
    private var _score = mutableStateOf(0)

    val index: Int get() = _index.value
    val score: Int get() = _score.value

    fun currentQuestion(): Question? =
        selectedQuestions.getOrNull(index)

    fun answer(optionIndex: Int) {
        if (isFinished()) return

        val q = selectedQuestions[index]
        if (optionIndex == q.correctIndex) {
            _score.value++
        }
        _index.value++
    }

    fun isFinished(): Boolean =
        index >= selectedQuestions.size

    fun finalScore(): Int = score

    fun getTotalQuestions(): Int = _totalQuestions
}
