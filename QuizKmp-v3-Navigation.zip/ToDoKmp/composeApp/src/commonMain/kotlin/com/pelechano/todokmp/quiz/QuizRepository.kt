package com.pelechano.todokmp.quiz
object QuizRepository {
    val questions = listOf(
        // --- TECNOLOGIA I KMP (1-10) ---
        Question("Llenguatge principal de KMP?", listOf("Java", "Swift", "Kotlin", "C#"), 2),
        Question("Creador de Kotlin?", listOf("Google", "JetBrains", "Apple", "Microsoft"), 1),
        Question("Format de recursos en Compose?", listOf("JSON", "XML", "YAML", "TXT"), 1),
        Question("Android és propietat de?", listOf("Meta", "Google", "Oracle", "Tesla"), 1),
        Question("Extensió de fitxers Kotlin?", listOf(".java", ".kt", ".exe", ".swift"), 1),
        Question("Què significa UI?", listOf("User Interface", "Unit Internal", "User Index", "Unique ID"), 0),
        Question("Cervell de l'ordinador?", listOf("RAM", "GPU", "CPU", "SSD"), 2),
        Question("Protocol segur de web?", listOf("HTTP", "HTTPS", "FTP", "SSH"), 1),
        Question("Base de dades per a KMP?", listOf("Room", "SQLDelight", "Oracle", "MongoDB"), 1),
        Question("Darrera versió de l'Apple iPhone?", listOf("iOS", "macOS", "watchOS", "tvOS"), 0),

        // --- GEOGRAFIA (11-25) ---
        Question("Capital de França?", listOf("Madrid", "París", "Roma", "Berlin"), 1),
        Question("Capital d'Espanya?", listOf("València", "Sevilla", "Madrid", "Bilbao"), 2),
        Question("On estan les Piràmides?", listOf("Mèxic", "Egipte", "Xina", "Grècia"), 1),
        Question("Riu més llarg del món?", listOf("Nil", "Amazones", "Ebre", "Danubi"), 1),
        Question("País del sol naixent?", listOf("Xina", "Corea", "Japó", "Tailàndia"), 2),
        Question("Continents al món?", listOf("5", "6", "7", "4"), 1),
        Question("Capital d'Itàlia?", listOf("Nàpols", "Milà", "Roma", "Venècia"), 2),
        Question("Oceà més gran?", listOf("Atlàntic", "Índic", "Pacífic", "Àrtic"), 2),
        Question("Muntanya més alta?", listOf("K2", "Everest", "Teide", "Mont Blanc"), 1),
        Question("On és la Torre Eiffel?", listOf("Londres", "Berlín", "París", "Roma"), 2),
        Question("Capital de Portugal?", listOf("Porto", "Lisboa", "Coïmbra", "Faro"), 1),
        Question("País més gran del món?", listOf("EUA", "Xina", "Rússia", "Canadà"), 2),
        Question("On es parla Català?", listOf("Espanya", "Andorra", "França/Itàlia", "Totes"), 3),
        Question("Capital d'Alemanya?", listOf("Múnic", "Frankfurt", "Berlín", "Hamburg"), 2),
        Question("On és el Gran Canyó?", listOf("Canadà", "EUA", "Mèxic", "Brasil"), 1),

        // --- CIÈNCIA I MATES (26-40) ---
        Question("2 + 2 * 2 és?", listOf("8", "6", "4", "2"), 1),
        Question("Planeta més proper al Sol?", listOf("Venus", "Mart", "Mercuri", "Terra"), 2),
        Question("Símbol de l'aigua?", listOf("CO2", "H2O", "O2", "NaCl"), 1),
        Question("Color de la clorofil·la?", listOf("Roig", "Blau", "Groc", "Verd"), 3),
        Question("L'or és un...?", listOf("Gas", "Metall", "Líquid", "Plàstic"), 1),
        Question("Quant val el número Pi?", listOf("3.12", "3.14", "3.16", "3.18"), 1),
        Question("Planeta amb anells?", listOf("Mart", "Saturn", "Venus", "Neptú"), 1),
        Question("Color del cel?", listOf("Roig", "Verd", "Blau", "Negre"), 2),
        Question("Quant és 10 / 2?", listOf("2", "4", "5", "10"), 2),
        Question("Satèl·lit de la Terra?", listOf("Sol", "Lluna", "Mart", "Venus"), 1),
        Question("Símbol de l'Oxigen?", listOf("Ox", "O", "O2", "H"), 1),
        Question("Animals que mamen?", listOf("Ocells", "Mamífers", "Peixos", "Rèptils"), 1),
        Question("L'aranya té... potes?", listOf("6", "8", "10", "12"), 1),
        Question("Gas que respirem?", listOf("Oxigen", "Nitrogen", "Heli", "Argó"), 0),
        Question("La Terra és...?", listOf("Plana", "Esfèrica", "Cub", "Triangular"), 1),

        // --- CULTURA I MISCEL·LÀNIA (41-50) ---
        Question("Qui va pintar la Gioconda?", listOf("Picasso", "Da Vinci", "Dalí", "Miró"), 1),
        Question("Idioma més parlat?", listOf("Anglès", "Xinès", "Castellà", "Hindi"), 1),
        Question("Instrument de 6 cordes?", listOf("Violí", "Piano", "Guitarra", "Flauta"), 2),
        Question("Any del descobriment d'Amèrica?", listOf("1492", "1789", "1212", "1900"), 0),
        Question("Quant dura un partit de futbol?", listOf("45 min", "60 min", "90 min", "10 min"), 2),
        Question("On va néixer Dalí?", listOf("Barcelona", "Figueres", "Girona", "Reus"), 1),
        Question("Quants mesos tenen 28 dies?", listOf("1", "Tots", "2", "Cap"), 1),
        Question("Color de la sang?", listOf("Blau", "Verd", "Roig", "Blanc"), 2),
        Question("Sentit de l'oïda serveix per...?", listOf("Veure", "Olar", "Escoltar", "Tocar"), 2),
        Question("Dia de Nadal?", listOf("24 Des", "25 Des", "26 Des", "1 Gen"), 1)
    )
}