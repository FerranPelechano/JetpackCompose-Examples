package com.pelechano.todokmp.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.pelechano.todokmp.ui.HomeScreen
import com.pelechano.todokmp.ui.QuizScreen

/*
----- ERRADA EN NAVEGACIÓ -----
implementation("org.jetbrains.androidx.navigation:navigation-compose:2.8.0-alpha10")
La llibreria de Navigation està intentant cridar a un mètode de SavedState que espera un objecte Bundle,
però a la JVM (Desktop) les llibreries no estan alineades i el mètode no existeix tal com s'espera.
Llibreries Alpha NO -> Navegació manual!
*/


enum class Screen {
    Home, Quiz
}

@Composable
fun NavigationWrapper(){
    var currentScreen by remember { mutableStateOf(Screen.Home) }
    when (currentScreen) {
        Screen.Home -> {
            HomeScreen(
                onStartQuiz = { currentScreen = Screen.Quiz }
            )
        }
        Screen.Quiz -> {
            QuizScreen(
                onBack = { currentScreen = Screen.Home }
            )
        }
    }
}