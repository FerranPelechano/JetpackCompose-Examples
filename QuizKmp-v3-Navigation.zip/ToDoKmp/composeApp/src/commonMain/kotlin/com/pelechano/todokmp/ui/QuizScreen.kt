package com.pelechano.todokmp.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pelechano.todokmp.quiz.QuizEngine
import org.jetbrains.compose.resources.stringResource
import todokmp.composeapp.generated.resources.Res
import todokmp.composeapp.generated.resources.final_score_msg
import todokmp.composeapp.generated.resources.finished_msg
import todokmp.composeapp.generated.resources.goTo_homeScreen
import todokmp.composeapp.generated.resources.question_progress
import todokmp.composeapp.generated.resources.restart_button
import todokmp.composeapp.generated.resources.score_label


@Composable
fun QuizScreen(onBack: () -> Unit) {
    var engine by remember { mutableStateOf(QuizEngine()) }
    val question = engine.currentQuestion()
    val totalQuestions = engine.getTotalQuestions()
    val currentIndex = if (question != null) engine.index + 1 else totalQuestions
    val progress = engine.index.toFloat() / totalQuestions

    Column(
        modifier = Modifier.fillMaxWidth().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Start
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = stringResource(Res.string.goTo_homeScreen)
                )
            }
        }

        Text(
            text = stringResource(Res.string.score_label, engine.finalScore()),
            fontSize = 28.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (question != null) {
            LinearProgressIndicator(
                progress = { progress.coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(8.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))


            Text(
                text = stringResource(Res.string.question_progress, currentIndex, totalQuestions),
                fontSize = 18.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = question.text,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                question.options.forEachIndexed { index, option ->
                    Button(
                        onClick = { engine.answer(index) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(option)
                    }
                }
            }
        } else {

            Text(stringResource(Res.string.finished_msg))
            Text(
                text = stringResource(Res.string.final_score_msg, engine.finalScore(), totalQuestions)
            )

            Spacer(modifier = Modifier.height(24.dp))

            Button(onClick = { engine = QuizEngine() }) {
                Text(stringResource(Res.string.restart_button))
            }
            Button(onClick = onBack) {
                Text(stringResource(Res.string.goTo_homeScreen))
            }

        }
    }
}