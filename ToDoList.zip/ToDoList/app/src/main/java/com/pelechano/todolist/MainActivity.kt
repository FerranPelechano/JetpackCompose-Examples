package com.pelechano.todolist

import android.R.attr.fontWeight
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.layout.ModifierLocalBeyondBoundsLayout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontWeight.Companion.Bold
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.pelechano.todolist.database.ToDoDao
import com.pelechano.todolist.database.ToDoDatabase
import com.pelechano.todolist.database.ToDoItem
import com.pelechano.todolist.ui.theme.ToDoListTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import java.lang.Integer.toString

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ToDoListTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Screen(
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}


fun getToDoDao(context: android.content.Context): ToDoDao {
    return ToDoDatabase.getDatabase(context.applicationContext).ToDoDao()
}


@Composable
fun Screen(modifier: Modifier = Modifier) {
    val context= LocalContext.current
    val todoDao = remember {getToDoDao(context)}
    val coroutineScope = rememberCoroutineScope()
    val todoList: List<ToDoItem> by todoDao.getAllTodos().collectAsState(initial = emptyList())

    var textInput by rememberSaveable { mutableStateOf("") }

    val scrollState= rememberScrollState()

    Column(
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier= Modifier
            .fillMaxHeight()
            .verticalScroll(scrollState)
    ) {
        Text(
            text = "To Do List",
            fontWeight = FontWeight.Bold,
            modifier = modifier
        )
        Spacer(Modifier.size(8.dp))
        Row(
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
            modifier= Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ){
            OutlinedTextField(
                value = textInput,
                label = {Text(stringResource(R.string.placeholder))},
                singleLine = true,
                onValueChange = {textInput = it}
            )
            Spacer(Modifier.size(8.dp))
            Button(
                onClick = {
                    if (textInput.isNotBlank()){
                        val newToDo = ToDoItem(task=textInput, isCompleted = false)
                        coroutineScope.launch(Dispatchers.IO) {
                            todoDao.insert(newToDo)
                        }
                        textInput=""
                    }

                }
            ) {
                Image(painterResource(R.drawable.outline_add_24), contentDescription = null)
            }
        }
        Spacer(Modifier.size(8.dp))
        todoList.forEach { item -> ElementLlistaToDo(item.task,item.id,item.isCompleted,
            onDeleteClick={
                coroutineScope.launch(Dispatchers.IO) {
                    todoDao.deleteById(item.id)
                }
            },
            onDoneClick={
                coroutineScope.launch(Dispatchers.IO) {
                    todoDao.updateCompletedState(item.id, !item.isCompleted)
                }
            }
        )
        }
    }

}

    @Composable
    fun ElementLlistaToDo(task: String, id: Int, isCompleted: Boolean, onDeleteClick: () -> Unit, onDoneClick: () -> Unit) {
        Row(
            horizontalArrangement = Arrangement.Start,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)

        ) {

            IconButton(
                onClick = onDoneClick
            ) {
                Image(painterResource(
                    if (isCompleted) R.drawable.outline_check_box_24 else R.drawable.outline_check_box_outline_blank_24), contentDescription = null)
            }
            Spacer(Modifier.size(8.dp))
            Text(
                task,
                modifier = Modifier.weight(1f),
                textDecoration = if (isCompleted) TextDecoration.LineThrough else null,
                color = if (isCompleted) Color.Gray else LocalContentColor.current
            )
            Spacer(Modifier.size(8.dp))
            IconButton(
                onClick = onDeleteClick
            ) {
                Image(
                    painterResource(R.drawable.outline_delete_24),
                    contentDescription = toString(id)
                )
            }
        }
    }


@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    ToDoListTheme {
        Screen()
    }
}