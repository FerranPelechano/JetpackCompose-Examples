package com.pelechano.todolist.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ToDoDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(todo: ToDoItem)

    @Delete
    suspend fun delete(todo: ToDoItem)

    @Query("UPDATE todo_items SET isCompleted = :completed WHERE id = :itemId")
    suspend fun updateCompletedState(itemId: Int, completed: Boolean)

    @Query("DELETE FROM todo_items WHERE id = :itemId")
    suspend fun deleteById(itemId: Int)

    @Query("SELECT * FROM todo_items ORDER BY id DESC")
    fun getAllTodos(): Flow<List<ToDoItem>>
}