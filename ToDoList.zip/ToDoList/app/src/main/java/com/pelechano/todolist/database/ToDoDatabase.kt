package com.pelechano.todolist.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [ToDoItem::class], version = 1, exportSchema = false)
abstract class ToDoDatabase : RoomDatabase() {
    abstract fun ToDoDao(): ToDoDao

    companion object {
        @Volatile
        private var BD: ToDoDatabase? = null

        fun getDatabase(context: Context): ToDoDatabase {
            return BD ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ToDoDatabase::class.java,
                    "ToDoItems_database"
                ).build()
                BD = instance
                instance
            }
        }
    }
}