package com.pelechano.todokmp.quiz

object QuizRepository {

    val questions = listOf(
        Question(
            "Capital de França?",
            listOf("Madrid", "París", "Roma", "Berlin"),
            1
        ),
        Question(
            "2 + 2 = ?",
            listOf("3", "4", "5", "6"),
            1
        ),
        Question(
            "Color del cel?",
            listOf("Roig", "Verd", "Blau", "Negre"),
            2
        ),
        Question(
            "Planeta roig?",
            listOf("Venus", "Mart", "Júpiter", "Saturn"),
            1
        ),
        Question(
            "Llenguatge KMP?",
            listOf("Java", "Swift", "Kotlin", "C#"),
            2
        ),
        Question(
            "Android és de?",
            listOf("Google", "Apple", "Microsoft", "Meta"),
            0
        ),
        Question(
            "Compose és?",
            listOf("UI Toolkit", "Base de dades", "SO", "Servidor"),
            0
        )
    )
}
