package com.pelechano.todokmp.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pelechano.todokmp.quiz.QuizEngine

@Composable
fun QuizScreen() {

    var engine by remember { mutableStateOf(QuizEngine()) }
    val question = engine.currentQuestion()
    val totalQuestions = engine.getTotalQuestions()
    val currentIndex = if (question != null) engine.index + 1  else totalQuestions
    val progress = engine.index.toFloat() / totalQuestions

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Text(
            text = "Marcador: ${engine.finalScore()}",
            fontSize = 28.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (question != null) {

            LinearProgressIndicator(
                progress = { progress.coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Pregunta $currentIndex de $totalQuestions",
                fontSize = 18.sp
            )

            Spacer(modifier = Modifier.height(16.dp))
        }

        if (question != null) {

            Text(
                text = question.text,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                question.options.forEachIndexed { index, option ->
                    Button(
                        onClick = { engine.answer(index) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(option)
                    }
                }
            }

        } else {

            Text("Has acabat!")
            Text("Marcador Final: ${engine.finalScore()} / $totalQuestions")

            Spacer(modifier = Modifier.height(24.dp))

            Button(onClick = { engine = QuizEngine() }) {
                Text("Torna a començar")
            }
        }
    }
}
